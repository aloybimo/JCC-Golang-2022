-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2022 at 10:22 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_quiz3`
--
CREATE DATABASE IF NOT EXISTS `db_quiz3` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `db_quiz3`;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `image_url` varchar(100) NOT NULL,
  `release_year` int(10) NOT NULL,
  `price` varchar(100) NOT NULL,
  `total_page` int(10) NOT NULL,
  `thickness` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `category_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `title`, `description`, `image_url`, `release_year`, `price`, `total_page`, `thickness`, `created_at`, `updated_at`, `category_id`) VALUES
(1, 'Harry Potter III', 'Continue 2nd edition of Harry Potter', 'https://www.youtube.com', 2004, 'Rp. 200.000', 200, 'sedang', '2022-03-27 23:21:39', '2022-03-27 23:21:39', 1),
(2, 'Harry Potter IV', 'Continue 3rd edition of Harry Potter', 'https://www.youtube.com/', 2006, 'Rp. 200.000', 205, 'tebal', '2022-03-27 23:23:47', '2022-03-27 23:23:47', 1),
(6, 'algoritma', 'deskripsi algoritma', 'https://www.google.com/', 2001, 'Rp. 50.000', 210, 'tebal', '2022-03-28 02:42:22', '2022-03-28 02:42:22', 1),
(7, '2 algoritma', 'deskripsi 2 algoritma', 'https://www.google.com/', 2003, 'Rp. 50.000', 210, 'tebal', '2022-03-28 03:13:44', '2022-03-28 03:13:44', 1),
(8, 'Menghilangkan Stres', 'deskripsi teknik menghilangkan stres', 'https://www.google.com/', 2008, 'Rp. 50.000', 210, 'tebal', '2022-03-28 03:14:36', '2022-03-28 03:14:36', 2),
(9, 'Menjadi Bagian Filosofi Teras', 'deskripsi teknik filosofi teras', 'https://www.google.com/', 2013, 'Rp. 50.000', 210, 'tebal', '2022-03-28 03:15:25', '2022-03-28 03:15:25', 2);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Fiction', '2022-03-27 17:00:28', '2022-03-27 17:00:28'),
(2, 'Psychology', '2022-03-27 17:00:28', '2022-03-27 17:00:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`);
